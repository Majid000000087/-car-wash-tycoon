using System;
using UnityEngine;

/// <summary>
/// Serializable local save data for Car Wash Tycoon.
/// PlayerPrefs stores one JSON string so the save remains easy to inspect, migrate, and backup.
/// </summary>
[Serializable]
public sealed class SaveData
{
    public double cash;
    public long lastSaveUtcTicks;
    public int[] stationLevels = new int[4];
    public bool[] managerUnlocked = new bool[4];
    public long speedBoostEndUtcTicks;
    public long vipSportsCarEndUtcTicks;
    public bool offlineTriplePending;
    public int stationUpgradeCount;
    public int totalCarsWashed;
}

/// <summary>
/// Small static persistence facade. All gameplay state is serialized through SaveData.
/// </summary>
public static class SaveSystem
{
    private const string SaveKey = "CarWashTycoon.SaveData.v1";

    public static SaveData LoadOrCreate()
    {
        if (!PlayerPrefs.HasKey(SaveKey))
        {
            SaveData fresh = CreateDefault();
            Save(fresh);
            return fresh;
        }

        try
        {
            string json = PlayerPrefs.GetString(SaveKey, string.Empty);
            SaveData data = JsonUtility.FromJson<SaveData>(json);
            Normalize(data);
            return data;
        }
        catch (Exception exception)
        {
            Debug.LogError($"[SaveSystem] Save data was invalid. A fresh save was created. {exception}");
            SaveData fresh = CreateDefault();
            Save(fresh);
            return fresh;
        }
    }

    public static void Save(SaveData data)
    {
        if (data == null)
        {
            Debug.LogError("[SaveSystem] Cannot save null data.");
            return;
        }

        data.lastSaveUtcTicks = DateTime.UtcNow.Ticks;
        Normalize(data);
        PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(data));
        PlayerPrefs.Save();
    }

    public static void DeleteSave()
    {
        PlayerPrefs.DeleteKey(SaveKey);
        PlayerPrefs.Save();
    }

    public static SaveData CreateDefault()
    {
        SaveData data = new SaveData
        {
            cash = 100d,
            lastSaveUtcTicks = DateTime.UtcNow.Ticks,
            stationUpgradeCount = 0,
            totalCarsWashed = 0,
            offlineTriplePending = false
        };

        for (int i = 0; i < 4; i++)
        {
            data.stationLevels[i] = 1;
            data.managerUnlocked[i] = false;
        }

        return data;
    }

    private static void Normalize(SaveData data)
    {
        if (data == null)
        {
            return;
        }

        if (data.stationLevels == null || data.stationLevels.Length != 4)
        {
            data.stationLevels = new[] { 1, 1, 1, 1 };
        }

        if (data.managerUnlocked == null || data.managerUnlocked.Length != 4)
        {
            data.managerUnlocked = new[] { false, false, false, false };
        }

        for (int i = 0; i < 4; i++)
        {
            data.stationLevels[i] = Mathf.Max(1, data.stationLevels[i]);
        }

        data.cash = Math.Max(0d, data.cash);
        data.totalCarsWashed = Mathf.Max(0, data.totalCarsWashed);
        data.stationUpgradeCount = Mathf.Max(0, data.stationUpgradeCount);
    }
}
