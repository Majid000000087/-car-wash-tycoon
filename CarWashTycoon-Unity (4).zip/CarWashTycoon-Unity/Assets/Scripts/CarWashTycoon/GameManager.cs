using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Global economy and orchestration controller. Keep exactly one instance in the first scene.
/// </summary>
public sealed class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Economy formulas")]
    [SerializeField, Min(0)] private double baseUpgradeCost = 100d;
    [SerializeField, Min(0)] private double baseRevenuePerWash = 15d;
    [SerializeField, Range(1f, 2f)] private double upgradeGrowth = 1.15d;
    [SerializeField, Range(1f, 2f)] private double revenueGrowth = 1.12d;

    [Header("Idle loop")]
    [SerializeField, Min(0.1f)] private float customerSpawnIntervalSeconds = 6f;
    [SerializeField, Min(1)] private int maximumOfflineHours = 4;
    [SerializeField] private bool autoSaveEveryFrame = false;

    [Header("Scene references")]
    [SerializeField] private UnityAdsManager unityAdsManager;
    [SerializeField] private UIManager uiManager;
    [SerializeField] private CarWashStation[] stations = new CarWashStation[4];

    private readonly List<CarWashStation> registeredStations = new List<CarWashStation>(4);
    private SaveData saveData;
    private float customerTimer;
    private float lastVipPayoutRealtime = -Mathf.Infinity;
    private double pendingOfflineEarnings;
    private bool offlineCalculated;
    private bool applicationQuitting;

    public double Cash => saveData == null ? 0d : saveData.cash;
    public double PendingOfflineEarnings => pendingOfflineEarnings;
    public SaveData CurrentSave => saveData;
    public int MaximumOfflineHours => maximumOfflineHours;
    public bool IsSpeedBoostActive => saveData != null && DateTime.UtcNow.Ticks < saveData.speedBoostEndUtcTicks;
    public bool IsVipSportsCarActive => saveData != null && DateTime.UtcNow.Ticks < saveData.vipSportsCarEndUtcTicks;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
        saveData = SaveSystem.LoadOrCreate();
    }

    private void Start()
    {
        SortAndApplyStationData();
        CalculateOfflineEarningsOnce();
        StartCoroutine(AutoSaveRoutine());

        if (stations.Length > 0 && stations[0] != null)
        {
            stations[0].ReceiveCar();
        }

        uiManager?.RefreshAll();
        if (unityAdsManager == null)
        {
            unityAdsManager = UnityAdsManager.Instance;
        }
    }

    private void Update()
    {
        customerTimer += Time.deltaTime;
        if (customerTimer >= customerSpawnIntervalSeconds)
        {
            customerTimer = 0f;
            TryDispatchNewCar();
        }

        for (int i = 0; i < registeredStations.Count; i++)
        {
            if (registeredStations[i] != null && registeredStations[i].ManagerUnlocked)
            {
                registeredStations[i].TryStartWash();
            }
        }

        if (autoSaveEveryFrame)
        {
            SaveNow();
        }
    }

    public void RegisterStation(CarWashStation station)
    {
        if (station == null || registeredStations.Contains(station))
        {
            return;
        }

        registeredStations.Add(station);
    }

    public void UnregisterStation(CarWashStation station)
    {
        registeredStations.Remove(station);
    }

    public CarWashStation GetStation(int index)
    {
        if (index < 0 || index >= stations.Length)
        {
            return null;
        }

        return stations[index];
    }

    public void RegisterStationArray(CarWashStation[] sceneStations)
    {
        stations = sceneStations ?? Array.Empty<CarWashStation>();
        SortAndApplyStationData();
    }

    private void SortAndApplyStationData()
    {
        Array.Sort(stations, (a, b) => a == null ? 1 : b == null ? -1 : a.StationIndex.CompareTo(b.StationIndex));
        for (int i = 0; i < stations.Length && i < 4; i++)
        {
            if (stations[i] != null)
            {
                stations[i].ApplySaveState(saveData.stationLevels[i], saveData.managerUnlocked[i]);
            }
        }
    }

    public void NotifyStationUpgraded(CarWashStation station)
    {
        if (station == null || station.StationIndex < 0 || station.StationIndex >= 4)
        {
            return;
        }

        saveData.stationLevels[station.StationIndex] = station.Level;
        saveData.stationUpgradeCount++;

        if (saveData.stationUpgradeCount % 4 == 0)
        {
            unityAdsManager?.ShowInterstitial();
        }

        SaveNow();
        uiManager?.RefreshAll();
    }

    public void NotifyManagerUnlocked(CarWashStation station)
    {
        if (station == null || station.StationIndex < 0 || station.StationIndex >= 4)
        {
            return;
        }

        saveData.managerUnlocked[station.StationIndex] = true;
        SaveNow();
        uiManager?.RefreshAll();
    }

    public bool SpendCash(double amount)
    {
        if (amount < 0d || saveData.cash < amount)
        {
            return false;
        }

        saveData.cash -= amount;
        uiManager?.RefreshCash(Cash);
        return true;
    }

    public void AddCash(double amount)
    {
        if (amount <= 0d)
        {
            return;
        }

        saveData.cash += amount;
        uiManager?.RefreshCash(Cash);
    }

    public void OnStationPayout(CarWashStation station, double stationRevenue)
    {
        if (station == null)
        {
            return;
        }

        if (station.Type != CarWashStation.StationType.WaxAndPolish)
        {
            CarWashStation next = GetStation(station.StationIndex + 1);
            next?.ReceiveCar();
            return;
        }

        double payout = stationRevenue;
        if (IsVipSportsCarActive && Time.unscaledTime - lastVipPayoutRealtime >= 180f)
        {
            payout *= 10d;
            lastVipPayoutRealtime = Time.unscaledTime;
        }

        AddCash(payout);
        saveData.totalCarsWashed++;
        SaveNow();
        uiManager?.ShowPayout(payout);
        TryDispatchNewCar();
    }

    private void TryDispatchNewCar()
    {
        CarWashStation first = GetStation(0);
        if (first != null && !first.IsBusy && !first.IsComplete)
        {
            first.ReceiveCar();
        }
    }

    public float GetGlobalSpeedMultiplier()
    {
        return IsSpeedBoostActive ? 2f : 1f;
    }

    public static double CalculateUpgradeCost(int level)
    {
        int safeLevel = Mathf.Max(1, level);
        return 100d * Math.Pow(1.15d, safeLevel);
    }

    public static double CalculateRevenuePerWash(int level)
    {
        int safeLevel = Mathf.Max(1, level);
        return 15d * Math.Pow(1.12d, safeLevel);
    }

    public static string FormatCurrency(double amount)
    {
        amount = Math.Max(0d, amount);
        if (amount >= 1000000000d) return $"${amount / 1000000000d:0.##}B";
        if (amount >= 1000000d) return $"${amount / 1000000d:0.##}M";
        if (amount >= 1000d) return $"${amount / 1000d:0.##}K";
        return $"${amount:0}";
    }

    public void ActivateSpeedBoostFromRewardedAd()
    {
        unityAdsManager?.ShowRewarded(() =>
        {
            saveData.speedBoostEndUtcTicks = DateTime.UtcNow.AddMinutes(15).Ticks;
            SaveNow();
            uiManager?.RefreshAll();
        }, HandleAdUnavailable);
    }

    public void ActivateOfflineTripleFromRewardedAd()
    {
        unityAdsManager?.ShowRewarded(() =>
        {
            saveData.offlineTriplePending = true;
            SaveNow();
            uiManager?.RefreshAll();
        }, HandleAdUnavailable);
    }

    public void ActivateVipSportsCarFromRewardedAd()
    {
        unityAdsManager?.ShowRewarded(() =>
        {
            saveData.vipSportsCarEndUtcTicks = DateTime.UtcNow.AddMinutes(15).Ticks;
            lastVipPayoutRealtime = -Mathf.Infinity;
            SaveNow();
            uiManager?.RefreshAll();
        }, HandleAdUnavailable);
    }

    private void HandleAdUnavailable()
    {
        uiManager?.ShowAdUnavailable();
    }

    public void ClaimOfflineEarnings()
    {
        if (pendingOfflineEarnings <= 0d)
        {
            return;
        }

        AddCash(pendingOfflineEarnings);
        pendingOfflineEarnings = 0d;
        saveData.offlineTriplePending = false;
        saveData.lastSaveUtcTicks = DateTime.UtcNow.Ticks;
        SaveNow();
        uiManager?.RefreshAll();
    }

    private void CalculateOfflineEarningsOnce()
    {
        if (offlineCalculated)
        {
            return;
        }

        offlineCalculated = true;
        DateTime lastSave = new DateTime(saveData.lastSaveUtcTicks, DateTimeKind.Utc);
        double elapsedSeconds = Math.Max(0d, (DateTime.UtcNow - lastSave).TotalSeconds);
        elapsedSeconds = Math.Min(elapsedSeconds, maximumOfflineHours * 60d * 60d);

        int finalLevel = saveData.stationLevels.Length >= 4 ? saveData.stationLevels[3] : 1;
        double revenuePerWash = CalculateRevenuePerWash(finalLevel);
        double estimatedWashes = elapsedSeconds / Math.Max(1d, customerSpawnIntervalSeconds);
        pendingOfflineEarnings = revenuePerWash * estimatedWashes;

        if (saveData.offlineTriplePending)
        {
            pendingOfflineEarnings *= 3d;
        }
    }

    private IEnumerator AutoSaveRoutine()
    {
        WaitForSeconds wait = new WaitForSeconds(10f);
        while (!applicationQuitting)
        {
            yield return wait;
            SaveNow();
        }
    }

    public void SaveNow()
    {
        if (saveData == null)
        {
            return;
        }

        for (int i = 0; i < stations.Length && i < 4; i++)
        {
            if (stations[i] != null)
            {
                saveData.stationLevels[i] = stations[i].Level;
                saveData.managerUnlocked[i] = stations[i].ManagerUnlocked;
            }
        }

        SaveSystem.Save(saveData);
    }

    private void OnApplicationPause(bool pauseStatus)
    {
        if (pauseStatus)
        {
            SaveNow();
        }
    }

    private void OnApplicationQuit()
    {
        applicationQuitting = true;
        SaveNow();
    }
}
