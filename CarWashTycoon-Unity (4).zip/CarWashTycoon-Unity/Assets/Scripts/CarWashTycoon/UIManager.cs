using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// UI facade for the canvas. Wire the public button methods from Button.onClick in the Inspector.
/// </summary>
public sealed class UIManager : MonoBehaviour
{
    [Serializable]
    private sealed class StationRow
    {
        public CarWashStation station;
        public TMP_Text levelText;
        public TMP_Text costText;
        public TMP_Text progressText;
        public Slider progressSlider;
        public Button upgradeButton;
        public Button managerButton;
        public TMP_Text managerButtonText;
    }

    [Header("Global labels")]
    [SerializeField] private TMP_Text cashText;
    [SerializeField] private TMP_Text carsWashedText;
    [SerializeField] private TMP_Text speedBoostTimerText;
    [SerializeField] private TMP_Text vipTimerText;
    [SerializeField] private TMP_Text offlineEarningsText;
    [SerializeField] private TMP_Text payoutToastText;

    [Header("Offline modal")]
    [SerializeField] private GameObject offlineModal;
    [SerializeField] private Button offlineClaimButton;
    [SerializeField] private Button offlineTripleAdButton;
    [SerializeField] private TMP_Text offlineModalAmountText;
    [SerializeField] private TMP_Text offlineModalTimeText;

    [Header("Station rows")]
    [SerializeField] private StationRow[] stationRows = Array.Empty<StationRow>();

    private Coroutine payoutRoutine;

    private void Start()
    {
        if (offlineClaimButton != null)
        {
            offlineClaimButton.onClick.AddListener(ClaimOfflineEarnings);
        }

        if (offlineTripleAdButton != null)
        {
            offlineTripleAdButton.onClick.AddListener(WatchOfflineTripleAd);
        }

        RefreshAll();
    }

    private void Update()
    {
        RefreshTimers();
        RefreshStationRows();
    }

    public void RefreshAll()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        RefreshCash(GameManager.Instance.Cash);
        if (carsWashedText != null)
        {
            carsWashedText.text = GameManager.Instance.CurrentSave.totalCarsWashed.ToString("N0");
        }

        RefreshOfflinePanel();
        RefreshTimers();
        RefreshStationRows();
    }

    public void RefreshCash(double amount)
    {
        if (cashText != null)
        {
            cashText.text = GameManager.FormatCurrency(amount);
        }
    }

    public void UpgradeStation(int rowIndex)
    {
        if (!TryGetStation(rowIndex, out CarWashStation station))
        {
            return;
        }

        if (!station.Upgrade())
        {
            ShowAdUnavailable("Not enough cash to upgrade this bay.");
        }

        RefreshAll();
    }

    public void UnlockManager(int rowIndex)
    {
        if (!TryGetStation(rowIndex, out CarWashStation station))
        {
            return;
        }

        if (station.UnlockManager())
        {
            GameManager.Instance.NotifyManagerUnlocked(station);
        }

        RefreshAll();
    }

    public void TapProcessStation(int rowIndex)
    {
        if (TryGetStation(rowIndex, out CarWashStation station))
        {
            station.TapProcess();
        }
    }

    public void WatchSpeedBoostAd()
    {
        GameManager.Instance?.ActivateSpeedBoostFromRewardedAd();
    }

    public void WatchOfflineTripleAd()
    {
        GameManager.Instance?.ActivateOfflineTripleFromRewardedAd();
        RefreshAll();
    }

    public void WatchVipSportsCarAd()
    {
        GameManager.Instance?.ActivateVipSportsCarFromRewardedAd();
    }

    public void ClaimOfflineEarnings()
    {
        GameManager.Instance?.ClaimOfflineEarnings();
        SetOfflineModalVisible(false);
        RefreshAll();
    }

    public void OpenOfflineModal()
    {
        RefreshOfflinePanel();
        SetOfflineModalVisible(true);
    }

    public void CloseOfflineModal()
    {
        SetOfflineModalVisible(false);
    }

    public void ShowPayout(double payout)
    {
        if (payoutToastText == null)
        {
            return;
        }

        payoutToastText.text = $"+{GameManager.FormatCurrency(payout)}";
        payoutToastText.gameObject.SetActive(true);
        if (payoutRoutine != null)
        {
            StopCoroutine(payoutRoutine);
        }

        payoutRoutine = StartCoroutine(HidePayoutToast());
    }

    public void ShowAdUnavailable()
    {
        ShowAdUnavailable("The ad is not ready. Please try again in a moment.");
    }

    public void ShowAdUnavailable(string message)
    {
        if (payoutToastText == null)
        {
            return;
        }

        payoutToastText.text = message;
        payoutToastText.gameObject.SetActive(true);
        if (payoutRoutine != null)
        {
            StopCoroutine(payoutRoutine);
        }

        payoutRoutine = StartCoroutine(HidePayoutToast());
    }

    private IEnumerator HidePayoutToast()
    {
        yield return new WaitForSecondsRealtime(2f);
        if (payoutToastText != null)
        {
            payoutToastText.gameObject.SetActive(false);
        }
    }

    private void RefreshTimers()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        if (speedBoostTimerText != null)
        {
            speedBoostTimerText.text = FormatRemaining(GameManager.Instance.CurrentSave.speedBoostEndUtcTicks, "2x Speed");
        }

        if (vipTimerText != null)
        {
            vipTimerText.text = FormatRemaining(GameManager.Instance.CurrentSave.vipSportsCarEndUtcTicks, "VIP Sports Car");
        }
    }

    private void RefreshOfflinePanel()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        string amount = GameManager.FormatCurrency(GameManager.Instance.PendingOfflineEarnings);
        if (offlineEarningsText != null) offlineEarningsText.text = amount;
        if (offlineModalAmountText != null) offlineModalAmountText.text = amount;
        if (offlineModalTimeText != null) offlineModalTimeText.text = $"Capped at {GameManager.Instance.MaximumOfflineHours} hours";
        if (offlineClaimButton != null) offlineClaimButton.interactable = GameManager.Instance.PendingOfflineEarnings > 0d;
    }

    private void RefreshStationRows()
    {
        for (int i = 0; i < stationRows.Length; i++)
        {
            StationRow row = stationRows[i];
            if (row == null || row.station == null)
            {
                continue;
            }

            if (row.levelText != null) row.levelText.text = $"Lv. {row.station.Level}";
            if (row.costText != null) row.costText.text = GameManager.FormatCurrency(GameManager.CalculateUpgradeCost(row.station.Level));
            if (row.progressText != null) row.progressText.text = row.station.State == CarWashStation.StationState.Washing ? $"{row.station.CycleProgress:P0}" : row.station.State.ToString();
            if (row.progressSlider != null) row.progressSlider.value = row.station.CycleProgress;
            if (row.managerButtonText != null) row.managerButtonText.text = row.station.ManagerUnlocked ? "Manager active" : "Hire manager";
            if (row.managerButton != null) row.managerButton.interactable = !row.station.ManagerUnlocked;
        }
    }

    private string FormatRemaining(long utcTicks, string label)
    {
        if (utcTicks <= 0)
        {
            return $"{label}: inactive";
        }

        TimeSpan remaining = new DateTime(utcTicks, DateTimeKind.Utc) - DateTime.UtcNow;
        if (remaining.TotalSeconds <= 0)
        {
            return $"{label}: inactive";
        }

        return $"{label}: {remaining.Minutes:00}:{remaining.Seconds:00}";
    }

    private bool TryGetStation(int rowIndex, out CarWashStation station)
    {
        station = null;
        if (rowIndex < 0 || rowIndex >= stationRows.Length || stationRows[rowIndex] == null)
        {
            return false;
        }

        station = stationRows[rowIndex].station;
        return station != null;
    }

    private void SetOfflineModalVisible(bool visible)
    {
        if (offlineModal != null)
        {
            offlineModal.SetActive(visible);
        }
    }
}
