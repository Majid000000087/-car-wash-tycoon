using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// One sequential bay in the car wash. Attach one instance to each of the four bay GameObjects.
/// </summary>
public sealed class CarWashStation : MonoBehaviour
{
    public enum StationType
    {
        PreWash = 0,
        FoamWash = 1,
        HighPressureRinse = 2,
        WaxAndPolish = 3
    }

    public enum StationState
    {
        Locked,
        Idle,
        Washing,
        WaitingForPreviousStation
    }

    [Header("Station identity")]
    [SerializeField] private StationType stationType;
    [SerializeField] private string displayName = "Pre-Wash";
    [SerializeField, Min(0)] private int baseUnlockCost = 0;

    [Header("Timing")]
    [SerializeField, Min(0.1f)] private float baseWashDurationSeconds = 5f;
    [SerializeField, Min(0.1f)] private float managerUnlockCost = 500f;

    [Header("Optional visual hooks")]
    [SerializeField] private GameObject lockedVisual;
    [SerializeField] private GameObject managerBadge;
    [SerializeField] private Animator stationAnimator;
    [SerializeField] private UnityEvent onWashStarted;
    [SerializeField] private UnityEvent onWashCompleted;

    private Coroutine washRoutine;
    private StationState state = StationState.Locked;
    private bool carReady;
    private float cycleProgress;

    public StationType Type => stationType;
    public string DisplayName => displayName;
    public int StationIndex => (int)stationType;
    public int Level { get; private set; } = 1;
    public bool ManagerUnlocked { get; private set; }
    public StationState State => state;
    public float CycleProgress => cycleProgress;
    public bool IsBusy => state == StationState.Washing;
    public bool IsComplete => carReady;
    public float BaseWashDurationSeconds => baseWashDurationSeconds;

    public event Action<CarWashStation> StateChanged;
    public event Action<CarWashStation, double> PayoutDispatched;

    private void Awake()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.RegisterStation(this);
        }
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.UnregisterStation(this);
        }
    }

    public void ApplySaveState(int level, bool managerUnlocked)
    {
        Level = Mathf.Max(1, level);
        ManagerUnlocked = managerUnlocked;
        state = ManagerUnlocked ? StationState.Idle : StationState.Idle;
        SetOptionalVisuals();
        StateChanged?.Invoke(this);
    }

    public bool CanUpgrade(out double cost)
    {
        cost = GameManager.CalculateUpgradeCost(Level);
        return GameManager.Instance != null && GameManager.Instance.Cash >= cost;
    }

    public bool Upgrade()
    {
        if (!CanUpgrade(out double cost))
        {
            return false;
        }

        GameManager.Instance.SpendCash(cost);
        Level++;
        GameManager.Instance.NotifyStationUpgraded(this);
        StateChanged?.Invoke(this);
        return true;
    }

    public bool UnlockManager()
    {
        if (ManagerUnlocked || GameManager.Instance == null || !GameManager.Instance.SpendCash(managerUnlockCost))
        {
            return false;
        }

        ManagerUnlocked = true;
        SetOptionalVisuals();
        StateChanged?.Invoke(this);
        return true;
    }

    /// <summary>Called by GameManager when a new customer enters the first bay.</summary>
    public void ReceiveCar()
    {
        if (state == StationState.Locked || carReady || IsBusy)
        {
            return;
        }

        carReady = true;
        if (ManagerUnlocked)
        {
            TryStartWash();
        }
        else
        {
            state = StationState.Idle;
            StateChanged?.Invoke(this);
        }
    }

    /// <summary>Call this from a tap button to process the station manually.</summary>
    public void TapProcess()
    {
        if (!ManagerUnlocked)
        {
            TryStartWash();
        }
    }

    public void TryStartWash()
    {
        if (!carReady || IsBusy || state == StationState.Locked)
        {
            return;
        }

        if (stationType != StationType.PreWash)
        {
            CarWashStation previous = GameManager.Instance.GetStation(StationIndex - 1);
            if (previous != null && !previous.IsComplete)
            {
                state = StationState.WaitingForPreviousStation;
                StateChanged?.Invoke(this);
                return;
            }
        }

        if (washRoutine == null)
        {
            washRoutine = StartCoroutine(WashRoutine());
        }
    }

    public double GetRevenuePerWash()
    {
        return GameManager.CalculateRevenuePerWash(Level);
    }

    public float GetCurrentDuration()
    {
        float speed = GameManager.Instance == null ? 1f : GameManager.Instance.GetGlobalSpeedMultiplier();
        return Mathf.Max(0.05f, baseWashDurationSeconds / speed);
    }

    private IEnumerator WashRoutine()
    {
        state = StationState.Washing;
        cycleProgress = 0f;
        stationAnimator?.SetBool("Washing", true);
        onWashStarted?.Invoke();
        StateChanged?.Invoke(this);

        float duration = GetCurrentDuration();
        while (cycleProgress < 1f)
        {
            cycleProgress += Time.deltaTime / duration;
            StateChanged?.Invoke(this);
            yield return null;
        }

        cycleProgress = 1f;
        carReady = false;
        state = StationState.Idle;
        stationAnimator?.SetBool("Washing", false);
        onWashCompleted?.Invoke();
        DispatchPayout();
        washRoutine = null;
        StateChanged?.Invoke(this);

        if (ManagerUnlocked && carReady)
        {
            TryStartWash();
        }
    }

    private void DispatchPayout()
    {
        double payout = GetRevenuePerWash();
        PayoutDispatched?.Invoke(this, payout);
        GameManager.Instance?.OnStationPayout(this, payout);
    }

    private void SetOptionalVisuals()
    {
        if (lockedVisual != null)
        {
            lockedVisual.SetActive(state == StationState.Locked);
        }

        if (managerBadge != null)
        {
            managerBadge.SetActive(ManagerUnlocked);
        }
    }
}
