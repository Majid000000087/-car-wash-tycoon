using System;
using UnityEngine;
using UnityEngine.Advertisements;

/// <summary>
/// Unity Ads integration for Android. Requires package com.unity.ads and the Advertisement Legacy API.
/// </summary>
public sealed class UnityAdsManager : MonoBehaviour, IUnityAdsInitializationListener, IUnityAdsLoadListener, IUnityAdsShowListener
{
    public static UnityAdsManager Instance { get; private set; }

    [Header("Unity Ads configuration")]
    [SerializeField] private string androidGameId = "800372087";
    [SerializeField] private bool testMode = true;
    [SerializeField] private string rewardedPlacementId = "BP_Rewarded_Android";
    [SerializeField] private string interstitialPlacementId = "BP_Interstitial_Android";
    [SerializeField] private string bannerPlacementId = "BP_Banner_Android";

    private Action rewardedSuccess;
    private Action rewardedFailure;
    private bool initialized;
    private bool rewardedLoaded;
    private bool interstitialLoaded;

    public bool IsInitialized => initialized;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        InitializeAds();
    }

    public void InitializeAds()
    {
        if (initialized || Advertisement.isInitialized)
        {
            initialized = true;
            LoadAllPlacements();
            return;
        }

        Advertisement.Initialize(androidGameId, testMode, this);
    }

    public void ShowRewarded(Action onRewarded, Action onUnavailable = null)
    {
        rewardedSuccess = onRewarded;
        rewardedFailure = onUnavailable;

        if (!initialized)
        {
            rewardedFailure?.Invoke();
            return;
        }

        if (!rewardedLoaded)
        {
            Advertisement.Load(rewardedPlacementId, this);
            rewardedFailure?.Invoke();
            return;
        }

        rewardedLoaded = false;
        Advertisement.Show(rewardedPlacementId, this);
    }

    public void ShowInterstitial()
    {
        if (!initialized)
        {
            return;
        }

        if (!interstitialLoaded)
        {
            Advertisement.Load(interstitialPlacementId, this);
            return;
        }

        interstitialLoaded = false;
        Advertisement.Show(interstitialPlacementId, this);
    }

    public void ShowBanner()
    {
        if (!initialized)
        {
            return;
        }

        Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_CENTER);
        Advertisement.Banner.Load(bannerPlacementId, new BannerLoadOptions
        {
            loadCallback = () => Advertisement.Banner.Show(bannerPlacementId),
            errorCallback = message => Debug.LogWarning($"[UnityAds] Banner failed to load: {message}")
        });
    }

    public void HideBanner()
    {
        Advertisement.Banner.Hide(false);
    }

    private void LoadAllPlacements()
    {
        Advertisement.Load(rewardedPlacementId, this);
        Advertisement.Load(interstitialPlacementId, this);
        ShowBanner();
    }

    public void OnInitializationComplete()
    {
        initialized = true;
        Debug.Log("[UnityAds] Initialization complete.");
        LoadAllPlacements();
    }

    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        initialized = false;
        Debug.LogError($"[UnityAds] Initialization failed: {error} - {message}");
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        if (placementId == rewardedPlacementId)
        {
            rewardedLoaded = true;
        }
        else if (placementId == interstitialPlacementId)
        {
            interstitialLoaded = true;
        }
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        if (placementId == rewardedPlacementId)
        {
            rewardedLoaded = false;
        }
        else if (placementId == interstitialPlacementId)
        {
            interstitialLoaded = false;
        }

        Debug.LogWarning($"[UnityAds] Failed to load {placementId}: {error} - {message}");
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        if (placementId == rewardedPlacementId)
        {
            rewardedFailure?.Invoke();
            rewardedSuccess = null;
            rewardedFailure = null;
        }

        Debug.LogWarning($"[UnityAds] Failed to show {placementId}: {error} - {message}");
        Advertisement.Load(placementId, this);
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log($"[UnityAds] Show started: {placementId}");
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Debug.Log($"[UnityAds] Show clicked: {placementId}");
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        if (placementId == rewardedPlacementId && showCompletionState == UnityAdsShowCompletionState.COMPLETED)
        {
            rewardedSuccess?.Invoke();
            rewardedSuccess = null;
            rewardedFailure = null;
        }
        else if (placementId == rewardedPlacementId)
        {
            rewardedFailure?.Invoke();
            rewardedSuccess = null;
            rewardedFailure = null;
        }

        Advertisement.Load(placementId, this);
    }
}
