# Car Wash Tycoon — Unity 2022.3 LTS Setup Guide

This package contains native Unity C# scripts only. It does not depend on the browser prototype. The scripts target Unity 2022.3 LTS or newer and Android.

## 1. Install required packages

Open **Window → Package Manager** and install the following packages.

| Package | Requirement |
|---|---|
| TextMeshPro | Required by `UIManager.cs` for labels. Import TMP Essentials when Unity prompts you. |
| Advertisement Legacy / Unity Ads | Required by `UnityAdsManager.cs`; package ID `com.unity.ads`. |

If your Unity Ads package version uses the newer Ads Mediation API instead of the Advertisement Legacy API, use the package version that exposes `UnityEngine.Advertisements`, `IUnityAdsInitializationListener`, `IUnityAdsLoadListener`, and `IUnityAdsShowListener`, or adapt the callback names to that package version.

In **Edit → Project Settings → Player → Android**, set the package identifier, minimum API level, target API level, orientation, and an IL2CPP ARM64 build as required by your release process. Configure the Android Game ID `800372087` in the Unity Dashboard and enable the Android platform.

## 2. Import the scripts

Create a folder named `Assets/Scripts/CarWashTycoon/` and copy these files into it:

- `SaveSystem.cs`
- `GameManager.cs`
- `CarWashStation.cs`
- `UnityAdsManager.cs`
- `UIManager.cs`

The scripts use `PlayerPrefs` only for the serialized JSON save string. No external database or server is required.

## 3. Create the scene hierarchy

Create one scene named `CarWashMain` with this hierarchy:

```text
CarWashMain
├── Systems
│   ├── GameManager
│   └── UnityAdsManager
├── CarWashFloor
│   ├── Station_PreWash
│   ├── Station_FoamWash
│   ├── Station_HighPressureRinse
│   └── Station_WaxAndPolish
├── CustomerQueue
└── Canvas
    ├── TopBar
    ├── StationPanel
    │   ├── Row_PreWash
    │   ├── Row_FoamWash
    │   ├── Row_HighPressureRinse
    │   └── Row_WaxAndPolish
    ├── BoostPanel
    ├── OfflineEarningsPanel
    ├── OfflineModal
    └── PayoutToast
```

This guide assumes the visual and car movement presentation is built with 2D sprites, tilemaps, or Animator state machines. The scripts provide the state and events; visual effects are connected through UnityEvents and the optional Animator reference.

## 4. Configure `UnityAdsManager`

Select **Systems/UnityAdsManager** and add `UnityAdsManager.cs`. Use these Inspector values:

| Field | Value |
|---|---|
| Android Game Id | `800372087` |
| Test Mode | `true` during development; set `false` only for production builds |
| Rewarded Placement Id | `BP_Rewarded_Android` |
| Interstitial Placement Id | `BP_Interstitial_Android` |
| Banner Placement Id | `BP_Banner_Android` |

The script initializes Unity Ads, preloads Rewarded and Interstitial placements, and requests a bottom-center anchored banner. It reloads placements after completion or failure. Do not call the rewarded callback yourself; the SDK invokes it only after a completed ad.

## 5. Configure the four station GameObjects

Add `CarWashStation.cs` to each station GameObject. Set the fields as follows.

| GameObject | Station Type | Display Name | Suggested Base Duration |
|---|---|---|---:|
| `Station_PreWash` | `PreWash` | `Pre-Wash` | 5 seconds |
| `Station_FoamWash` | `FoamWash` | `Foam Wash` | 7 seconds |
| `Station_HighPressureRinse` | `HighPressureRinse` | `High-Pressure Rinse` | 8 seconds |
| `Station_WaxAndPolish` | `WaxAndPolish` | `Wax & Polish` | 10 seconds |

Set `Base Unlock Cost` to `0` for all four stations if all bays should be available from the start. Set `Manager Unlock Cost` to the desired manager price; the default is `500`.

Optional fields:

- **Locked Visual:** assign a child GameObject containing a lock overlay.
- **Manager Badge:** assign a child GameObject that should appear after hiring the manager.
- **Station Animator:** assign an Animator with a boolean parameter named `Washing`.
- **On Wash Started / On Wash Completed:** connect water, foam, polish, sound, particle, and sprite animation effects.

The first station receives a car automatically. When a station completes, the script dispatches the car to the next sequential bay. Only the final Wax & Polish bay creates the customer payout.

## 6. Configure `GameManager`

Add `GameManager.cs` to **Systems/GameManager**. Assign:

- **Unity Ads Manager:** drag `Systems/UnityAdsManager`.
- **UI Manager:** drag the Canvas object that contains `UIManager.cs`.
- **Stations:** set array size to `4` and assign the four station objects in this exact order: Pre-Wash, Foam Wash, High-Pressure Rinse, Wax & Polish.

Recommended defaults:

| Field | Value |
|---|---:|
| Base Upgrade Cost | `100` |
| Base Revenue Per Wash | `15` |
| Upgrade Growth | `1.15` |
| Revenue Growth | `1.12` |
| Customer Spawn Interval Seconds | `6` |
| Maximum Offline Hours | `4` |

The formulas are evaluated as follows:

```text
Upgrade cost = 100 × (1.15 ^ station level)
Revenue per wash = 15 × (1.12 ^ station level)
```

The game starts with `$100`, level 1 stations, and all managers locked. To start with a different economy, change `SaveSystem.CreateDefault()`.

## 7. Configure the Canvas and `UIManager`

Add `UIManager.cs` to the root `Canvas` GameObject. Use a `Canvas Scaler` set to **Scale With Screen Size**. A reference resolution such as `1080 × 1920` works well for portrait mobile UI; use anchors so the banner-safe area remains at the bottom.

Assign the global labels:

- `Cash Text`: total cash.
- `Cars Washed Text`: completed customer count.
- `Speed Boost Timer Text`: 2× boost countdown.
- `Vip Timer Text`: VIP Sports Car boost countdown.
- `Offline Earnings Text`: current claimable offline amount.
- `Payout Toast Text`: temporary payout or error message.

Configure the Offline panel:

- `Offline Modal`: root panel GameObject.
- `Offline Claim Button`: normal claim button.
- `Offline Triple Ad Button`: button for the 3× offline-income rewarded ad.
- `Offline Modal Amount Text`: amount label.
- `Offline Modal Time Text`: cap/status label.

For `Station Rows`, set array size to `4`. Each row maps to one station and contains its level label, upgrade cost label, progress label, progress slider, upgrade button, manager button, and manager button label.

## 8. Wire UI Button events

Add these `Button.onClick` events. Use the Canvas object containing `UIManager.cs` as the target.

| Button | Method | Argument |
|---|---|---:|
| Pre-Wash Upgrade | `UIManager.UpgradeStation` | `0` |
| Foam Wash Upgrade | `UIManager.UpgradeStation` | `1` |
| High-Pressure Upgrade | `UIManager.UpgradeStation` | `2` |
| Wax & Polish Upgrade | `UIManager.UpgradeStation` | `3` |
| Pre-Wash Manager | `UIManager.UnlockManager` | `0` |
| Foam Wash Manager | `UIManager.UnlockManager` | `1` |
| High-Pressure Manager | `UIManager.UnlockManager` | `2` |
| Wax & Polish Manager | `UIManager.UnlockManager` | `3` |
| 2× Speed Rewarded Ad | `UIManager.WatchSpeedBoostAd` | none |
| 3× Offline Rewarded Ad | `UIManager.WatchOfflineTripleAd` | none |
| VIP Sports Car Rewarded Ad | `UIManager.WatchVipSportsCarAd` | none |
| Collect Offline Earnings | `UIManager.ClaimOfflineEarnings` | none |
| Open Offline Modal | `UIManager.OpenOfflineModal` | none |
| Close Offline Modal | `UIManager.CloseOfflineModal` | none |

For optional manual play, each station can also call `UIManager.TapProcessStation` with its station index. Once a manager is unlocked, the station processes automatically without tapping.

## 9. Save, offline earnings, and boost behavior

The save is written as JSON under the PlayerPrefs key `CarWashTycoon.SaveData.v1`. It includes cash, the four station levels, manager unlocks, total cars washed, upgrade count, last-save UTC ticks, and active boost expiration ticks.

`GameManager` saves on application pause, application quit, and every ten seconds. Offline earnings are calculated once on the next launch and capped at four hours. The offline rewarded ad sets a persisted pending 3× multiplier before the player claims the earnings.

The 2× speed reward lasts fifteen minutes. The VIP Sports Car reward lasts fifteen minutes and applies a 10× payout at most once every three minutes while active. Interstitial ads are requested automatically after every four station level upgrades. The banner is loaded and displayed at the bottom center after Unity Ads initialization.

## 10. Test checklist

1. Enter Play Mode and confirm the banner request is visible in the Unity Console.
2. Confirm the first station receives a car and the progress slider advances.
3. Hire the first manager and confirm the station continues without tapping.
4. Confirm the car moves through all four stations sequentially.
5. Upgrade any station and verify the cost follows the `100 × 1.15^level` formula.
6. Complete a full wash and verify the final bay adds `15 × 1.12^level` to cash.
7. Upgrade stations four times and confirm an interstitial show request is made.
8. Trigger each rewarded button in Unity Ads test mode and verify its timer label.
9. Pause/quit, wait, relaunch, and confirm offline earnings are available and capped at four hours.
10. Use the 3× offline rewarded option, relaunch or claim, and confirm the pending payout is tripled.
11. Delete the app's PlayerPrefs or use `SaveSystem.DeleteSave()` from a debug button to test a fresh profile.
