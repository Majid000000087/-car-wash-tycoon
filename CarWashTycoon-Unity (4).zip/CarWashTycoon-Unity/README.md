# Car Wash Tycoon — Unity Cloud Build Repository

This repository is a Unity 2022.3 LTS Android project skeleton containing the complete native C# game systems for the 2D isometric mobile idle car wash game.

## Included

- `Assets/Scripts/CarWashTycoon/SaveSystem.cs`
- `Assets/Scripts/CarWashTycoon/GameManager.cs`
- `Assets/Scripts/CarWashTycoon/CarWashStation.cs`
- `Assets/Scripts/CarWashTycoon/UnityAdsManager.cs`
- `Assets/Scripts/CarWashTycoon/UIManager.cs`
- `Assets/Scenes/CarWashMain.unity`
- Unity 2022.3 project settings with Android selected as the intended target.
- Unity Ads package `com.unity.ads`.
- Cloud Build setup instructions.

## Unity Cloud Build steps

1. Create an empty GitHub repository and upload the contents of this ZIP to its root. Do not upload the outer ZIP folder as an extra nesting level.
2. In Unity Cloud, create a new project or select an existing Unity project and open **DevOps / Version Control / Cloud Build**.
3. Connect the GitHub repository and select branch `main`.
4. Set the Unity Editor version to **2022.3.50f1** or another installed Unity 2022.3 LTS version.
5. Set the build target to **Android**.
6. Set the Android package name to `com.bluepeak.carwashtycoon` or your own reverse-domain identifier.
7. Add your Android keystore, alias, and password as Cloud Build secrets. The repository intentionally does not contain signing credentials.
8. In the Unity Ads Dashboard, configure Android Game ID `800372087` and these placements: `BP_Rewarded_Android`, `BP_Interstitial_Android`, and `BP_Banner_Android`.
9. Run a development build first with Unity Ads Test Mode enabled. Change `Test Mode` to `false` in `UnityAdsManager` only for a production build after verifying the live placements.
10. Build an APK or AAB from Cloud Build. No local PC Unity installation is required after the repository is connected.

## Important Cloud Build note

The scripts compile against Unity's Advertisement Legacy API (`UnityEngine.Advertisements`) and the interfaces `IUnityAdsInitializationListener`, `IUnityAdsLoadListener`, and `IUnityAdsShowListener`. If the Cloud project has a newer Ads package configured that no longer exposes this API, pin package `com.unity.ads` to a compatible version through `Packages/manifest.json` or update the adapter calls for the installed package API.

## Scene setup

`Assets/Scenes/CarWashMain.unity` contains the systems object and four sequential station objects wired into the `GameManager`. The UI canvas is intentionally minimal so the repository can build without imported art. Add your isometric tilemap, sprites, TextMeshPro labels, and button wiring using the detailed [Inspector setup guide](SETUP_GUIDE.md).

## Save data

The game stores one JSON payload in PlayerPrefs under `CarWashTycoon.SaveData.v1`. It persists cash, station levels, manager unlocks, upgrade count, total cars washed, last-save time, and active boost timers. Offline earnings are capped at four hours.
